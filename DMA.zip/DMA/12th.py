los = ("Chemistry","Biology","Maths","English")
n = input("Enter number of students to enter : ")
n = int(n)
rl = [1,2,3]
nm = ["Hir","Pinal","Radhika"]
slist = {1:["Chemistry","Biology","Maths"],2:["Maths","English"],3:["Biology","English"]}
smark = {1:[70,80,80],2:[33,55],3:[60,70]}
t1 = []
t2 = []
for i in range(n):
    r = input("enter roll : ")
    r = int(r)
    n1 = input("Enter name : ")
    rl.append(r)
    nm.append(n1)
    print("Enter for student " + n1)
    k = input("Enter number of subjects : ")
    k = int(k)
    for d in range(k):
        sn = input("name of the subject : ")
        sm = input("marks of the subject : ")
        sm = int(sm)
        t1.append(sn)
        t2.append(sm)
    slist[r] = t1
    smark[r] = t2
    t1 = []
    t2 = []
i = 0
for i in rl:
    tl = slist[i]
    t2 = smark[i]
    t = sum(t2)
    for j in los:
        if(j not in t1):
            k = los.index(j)
            t2.insert(k,"AB")
            t1.insert(k,"AB")
    print(str(i) + " " + nm[l] + str(t2) + " " + str(t))
    t1 = []
    t2 = []
    l = l + 1
print(slist)
print(smarks)
