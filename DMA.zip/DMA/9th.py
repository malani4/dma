k = [1,2,3,7,5,9,4,3,7,55,66]

i = 0
if len(k) % 3 != 0:
    print("false")

j - len(k) / 3
j = int(j)
r = 0
b = True
while i < j:
    print(i)
    temp = k[r] + k[r+1]
    if(temp != k[r+2]):
        b = False
    i = i + 1
    r = r + 3
if(b):
    print("True")
else:
    print("False")
