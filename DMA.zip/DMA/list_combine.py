l = [1,2,3,4,5,6,7]
print(l)
t = len(l)
i = 0
r = []
o = []
while (i < t):
    r.append(l[i])
    if(i + 1 != t):
        r.append(l[i+1])

    i = i + 2
    o.append(r)
    print(o)
    r = []
l.clear()
l = 0
print(l)
