finp = int(input("Enter number value"))
sinp = int(input("Enter another number value"))
if finp > sinp:
    while sinp<=finp:
        print(sinp)
        sinp = sinp + 1
elif sinp > finp:
    while finp <= sinp:
        print(finp)
        finp = finp + 1
else:
    print ("Loop can not be run as both numbers are same")
