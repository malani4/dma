#reverse of string in list done by sir

l = ["DEEP","SHETA","Bsc IT" ,"Student"]
ans = ""
op = []
for i in l:
    k = len(i)
    k = k - 1
    while (k >= 0):
        ans = ans + i[k]
        k = k - 1
    op.append(ans)
    ans = " "
print(op)
