finp = int(input("Enter number value"))
sinp = int(input("Enter another number value"))
if finp > sinp:
    print("first input is greater")
else:
    print("second is greater")
