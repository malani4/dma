l = [56,54,43,21,44,35,65]
k = len(l)
i = 0
while i <k:
    print(l[i])
    i = i + 1
for j in l:
    print(j)
