temp = [4, 6, 3, 8, 10, 5, 11]
print("Origenal list")
print(temp)
temp.sort()
print("sorted list")
print(temp)
res = []
i = 0
while i < len(temp)-1:
    res.append([temp[i] , temp[i+1]])
    i = i + 2
    
if(i == len(temp)):
    print("The consecutive element paired list is : " + str(res))
else:
    res.append([temp[i]])
    print("The consecutive element paired list is : " + str(res))
