d = {}
n = input("enter number of records")
n = int(n)
th = input("enter minimum threshhold value")
th = int(th)
temp = []
for i in range(n):
    k = input("enter roll number")
    k = int(k)
    j = input("number of subjects")
   
    j = int(j)
    for r in range(j):
        s1 = input("Enter subject name")
        temp.append(s1)
    d[k] = temp
    temp = []
   
print(d)
temp=[]
for i in d.keys():
    t = d[i]
    for j in t:
        if(j not in temp):
            temp.append(j)
ct = 0
for j in temp:
    for i in d.keys():
        t = d[i]
        ct = t.count(j)
    print(j)
    print(ct)
    ct = 0
