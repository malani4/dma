los = ("Maths","English","ss","Computer")
vinay = ["Maths","ss"]
vinay_marks = [33,66]
for i in los:
    if(i not in vinay):
        k = los.index(i)
        vinay_marks.insert(k,"AB")
print(vinay_marks)
