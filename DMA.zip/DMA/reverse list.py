#this string will revers
k = "man"
l = len(k)
i = 0
j = -1
while i < l:
    print(k[j])
    j = j - 1
    i = i + 1

